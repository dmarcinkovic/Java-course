package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Class used for the representation of expression.
 * 
 * @author david
 *
 */
public class Element {

	/**
	 * Method to convert Element to text.
	 * 
	 * @return Text representation of element.
	 */
	public String asText() {
		return "";
	}
}
